<?php
    phpinfo(); 
?>