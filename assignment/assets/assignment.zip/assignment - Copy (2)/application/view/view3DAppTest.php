<!DOCTYPE html>
<html lang="en">

<head> 
    <meta charset="UTF-8">
    <title>Test View</title>
</head>

<body>
    <h1>Initial 3D App Test View </h1>
    <?php
        echo $model1 . "<br>";
        echo $model2 . "<br>";
        echo $model3 . "<br>";
        echo $model4 . "<br>";
        echo $model5 . "<br>";
        echo $model6 . "<br>";
    ?>
    <p> If you are seeing the test data above Model 3D Image Data then your basic MVC framework is working</p>
</body>
</html>